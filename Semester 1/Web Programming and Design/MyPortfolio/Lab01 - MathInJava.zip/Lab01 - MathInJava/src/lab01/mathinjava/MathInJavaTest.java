/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01.mathinjava;

/**
 *
 * @author leonm
 */
public class MathInJavaTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creating the int variables
        int iNum1 = 14;
        int iNum2 = 3;
        int iAnswer;
        
        iAnswer = iNum1 + iNum2;
        System.out.println("Adding iNum1 and iNum2: " + iAnswer);
        
        iAnswer = iNum1 - iNum2;
        System.out.println("Subtracting iNum1 and iNum2: " + iAnswer);
        
        iAnswer = iNum1 * iNum2;
        System.out.println("Multiplying iNum1 and iNum2: " + iAnswer);
        
        iAnswer = iNum1 / iNum2;
        System.out.println("Dividing iNum1 and iNum2 (integer division):  " + iAnswer);
        
        iAnswer = iNum1 % iNum2;
        System.out.println("iNum1 modulo iNum2:  " + iAnswer);
        
        iAnswer = iNum1 += 5;
        System.out.println("Shorthand operator add 5 to iNum1:  " + iAnswer);
        
        iAnswer = ++iNum1;
        System.out.println("Increment operator on iNum1:  " + iAnswer);
        
        // This is to create a space on the output, it's purley aesthetical.
        System.out.println("                          ");
        System.out.println("                          ");
        
        // Creating the double variables
        double dNum1 = 14;
        double dNum2 = 3;
        double dAnswer;
        
        System.out.print("Dividing dNum1 by dNum2: ");
        dAnswer = dNum1 / dNum2;
        System.out.println(dAnswer);
        
        System.out.print("Double division rounded using Math method: ");
        dAnswer = Math.round(dNum1 / dNum2);
        System.out.println(dAnswer);
        
        System.out.print("dNum1 cubed using Multiplication: ");
        dAnswer = dNum1 * dNum1 * dNum1;
        System.out.println(dAnswer);
        
        System.out.print("dNum1 cubed using Math method: ");
        dAnswer = Math.pow(dNum1, 3);
        System.out.println(dAnswer);
    }
    
}
