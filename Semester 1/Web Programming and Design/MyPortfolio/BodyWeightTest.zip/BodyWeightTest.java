/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab02.scanner;

/**
 *
 * @author leonm
 */

import java.util.Scanner;

public class BodyWeightTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        final int minimumHeightFt = 5;
        final int minimumHeightInches = minimumHeightFt * 12;
        final int minimumWeight = 110;
        final int poundsPerInch = 5;
        
        
        Scanner readinput = new Scanner(System.in);
        
        System.out.println("Please enter your height in feet and inches: ");
        int feet = readinput.nextInt();
        int inches = readinput.nextInt();
        
        // Calculations
        int calculations = (feet * 12 + inches - minimumHeightInches) * poundsPerInch + minimumWeight;
        System.out.println("Your ideal bodyweight is " + calculations + " pounds");
        
        
        
    }
    
}
