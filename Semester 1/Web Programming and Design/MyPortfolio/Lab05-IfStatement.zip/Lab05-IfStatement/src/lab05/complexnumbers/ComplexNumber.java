/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05.complexnumbers;

import javax.swing.JOptionPane;

/**
 *
 * @author leonm
 */
public class ComplexNumber {

private double realPart;
private double imaginaryPart;


public String toString(){
    String output = "Complex Number: ";
    
    if (realPart == 0 && imaginaryPart == 0) {
    }
    
    else if (realPart < 0 && imaginaryPart < 0) {
        output += "(" + realPart + ")" + " + " + "(" + imaginaryPart + "i" + ")";
    }
    
    else if (realPart == 0 && imaginaryPart < 0) {
        output += "(" + imaginaryPart + "i" + ")";
    }
    
    else if (realPart == 0) {
        output += imaginaryPart + "i";
    }
    
    else if (imaginaryPart == 0 && realPart < 0){
        output += realPart;
    }
    
    else if (imaginaryPart == 0){
        output += realPart;
    }
    else if (realPart < 0){
        output += "(" + realPart + ") " + "+" + imaginaryPart + "i";
    }
    else if (imaginaryPart < 0){
        output += realPart + " + " + "(" + imaginaryPart + "i" + ")";
    }
    else {
        output += realPart + " + " + imaginaryPart + "i";
    }
    
    return output;
}

public void inputComplexNumber(){
    realPart = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter real part of complex number:"));
    imaginaryPart = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter imaginary part of complex number:"));
    
}
}
