/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg6.christmassong;

/**
 Use a switch statement in a for loop to control which lines get printed. Hint: Order the
cases carefully and avoid the break statement. Use a separate switch statement to
put the appropriate suffix on the day number (1st, 2nd, 3rd, etc.)
 */
public class ChristmasSong {
    
    public String toString(){
        
        int day_of_christmas = 1;
        String events = "";
        String suffix = "";
        String first_day = "A partridge in a pear tree\n";
        String second_day = "Two turtle doves, and\n";
        String third_day = "Three french hens,\n";
        String fourth_day = "Four calling birds,\n";
        String fifth_day = "Five golden rings,\n";
        String sixth_day = "Six geese a laying,\n";
        String seventh_day = "Seven swans a swimming,\n";
        String eighth_day = "Eight maids a milking,\n";
        String ninth_day = "Nine ladies dancing,\n";
        String tenth_day = "Ten lords a leaping,\n";
        String eleventh_day = "Eleven pipers piping,\n";
        String twelfth_day = "Twelve drummers drumming,\n";
        
        for (day_of_christmas = 1; day_of_christmas <= 12; day_of_christmas++) {
            
            switch (day_of_christmas){
                case 1:
                    suffix = "st";
                    break;
                case 2:
                    suffix = "nd";
                    break;
                case 3:
                    suffix = "rd";
                    break;
                case 4:
                    suffix = "th";
                    break;
                case 5:
                    suffix = "th";
                    break;
                case 6:
                    suffix = "th";
                    break;
                case 7:
                    suffix = "th";
                    break;
                case 8:
                    suffix = "th";
                    break;
                case 9:
                    suffix = "th";
                    break;
                case 10:
                    suffix = "th";
                    break;
                case 11:
                    suffix = "th";
                    break;
                case 12:
                    suffix = "th";
                    break;
            }
            
                String output = "On the " + day_of_christmas + suffix + " day of Christmas my true love sent to me\n";
            
                      switch (day_of_christmas){
                case 1:
                    events += first_day;
                    System.out.println(output + events);
                    break;
                case 2:
                    events = second_day += events;
                    System.out.println(output + events);
                    break;
                case 3:
                    events = third_day += events;
                    System.out.println(output + events);
                    break;
                case 4:
                    events = fourth_day += events;
                    System.out.println(output + events);
                    break;
                case 5:
                    events = fifth_day += events;
                    System.out.println(output + events);
                    break;
                case 6:
                    events = sixth_day += events;
                    System.out.println(output + events);
                    break;
                case 7:
                    events = seventh_day += events;
                    System.out.println(output + events);
                    break;
                case 8:
                    events = eighth_day += events;
                    System.out.println(output + events);
                    break;
                case 9:
                    events = ninth_day += events;
                    System.out.println(output + events);
                    break;
                case 10:
                    events = tenth_day += events;
                    System.out.println(output + events);
                    break;
                case 11:
                    events = eleventh_day += events;
                    System.out.println(output + events);
                    break;
                case 12:
                    events = twelfth_day += events;
                    System.out.println(output + events);
                    break;
            }
                    
        }
        
        
    return events;
    }
    
}