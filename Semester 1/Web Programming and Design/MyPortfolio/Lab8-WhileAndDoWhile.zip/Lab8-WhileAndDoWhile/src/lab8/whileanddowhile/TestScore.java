/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8.whileanddowhile;
import java.util.Scanner;

/**
 *
 * @author leonm
 */
public class TestScore {
    int scores;
    int score_count = 1;
    double total_scores;
    
    public void CalculateScore(int score_input){
  scores = score_input;
  Scanner scanner = new Scanner(System.in);
  
  while (score_count <= scores) {
                
      System.out.println("Enter score " + score_count);
      
      double newScore = scanner.nextDouble();    
                
      if (newScore > 0 && newScore < 101) {
          total_scores += newScore;          
          score_count++;
} 
                
      else {          
          System.out.println("Invalid Input");
}
                
                
  }

        
        
  
 

    }}

