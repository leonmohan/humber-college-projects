/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8.whileanddowhile;
import java.util.Scanner;
/**
 *
 * @author leonm
 */
public class Lab8WhileAndDoWhile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of test scores to be entered: ");
        int score_input = scanner.nextInt();
        
        System.out.println("You can now enter scores between 1 and 100\n");
        TestScore test = new TestScore();
        test.CalculateScore(score_input);
        
        System.out.println("Score Count: " + (test.score_count - 1));
        System.out.println("Score Total: " + test.total_scores);
    }
    
}
